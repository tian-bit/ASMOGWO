MaxIt=200;
a1=zeros(1,MaxIt);
a2=zeros(1,MaxIt);
a3=zeros(1,MaxIt);
for it=1:MaxIt
%     a=2-it*((2)/MaxIt);
    % ����Ȩ��
% a1=zeros(1,MaxIt);
% a2=zeros(1,MaxIt);
% a3=zeros(1,MaxIt);
      a(it)=2-it*((2)/MaxIt);
a1(it)=2 * (cos(0.5 * pi * ((it / MaxIt) * (it /MaxIt))));
      a2(it) = abs(cos(0.5 * pi * (it /MaxIt)));
      a3(it) = 2 - abs(0.5 * cos(0.5 * pi * (it / MaxIt)));
      A(it)=2.*a(it).*rand()-a(it);
      A1(it)=2.*a1(it).*rand()-a1(it);
       A2(it)=2.*a2(it).*rand()-a2(it);
       A3(it)=2.*a3(it).*rand()-a3(it);
end
plot(1:MaxIt,A);
xlabel('Tterations');
 ylabel('Coefficient vector A');
 title('Linear convergence factor a');
