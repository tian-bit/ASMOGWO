clear all
clc
drawing_flag = 1;
nVar = 10;
fobj = @(x) ZDT(x); % ZDT ���Ժ���
% Lower bound and upper bound
lb = zeros(1, nVar);
ub = ones(1, nVar);
VarSize = [1 nVar];
GreyWolves_num = 300;
MaxIt =80;  % Maximum Number of Iterations
Archive_size = 100;   % Repository Size

alpha = 0.5;  % Grid Inflation Parameter
nGrid = 10;   % Number of Grids per each Dimension
beta = 4; %=4;    % Leader Selection Pressure Parameter
gamma = 2;    % Extra (to be deleted) Repository Member Selection Pressure
decay_rate =0.06; % ˥����
a_initial = 2;
a_final = 0;

% Initialization
GreyWolves = CreateEmptyParticle(GreyWolves_num);
for i = 1:GreyWolves_num
    GreyWolves(i).Velocity = 0;
    GreyWolves(i).Position = zeros(1, nVar);
    for j = 1:nVar
        GreyWolves(i).Position(1, j) = unifrnd(lb(j), ub(j), 1);
    end
    GreyWolves(i).Cost = fobj(GreyWolves(i).Position')';
    GreyWolves(i).Best.Position = GreyWolves(i).Position;
    GreyWolves(i).Best.Cost = GreyWolves(i).Cost;
end

GreyWolves = DetermineDomination(GreyWolves);
Archive = GetNonDominatedParticles(GreyWolves);
Archive_costs = GetCosts(Archive);
G = CreateHypercubes(Archive_costs, nGrid, alpha);

for i = 1:numel(Archive)
    [Archive(i).GridIndex Archive(i).GridSubIndex] = GetGridIndex(Archive(i), G);
end

% MOGWO main loop
for it = 1:MaxIt
    % �������������ӵ���
    a = a_final + (a_initial - a_final) * exp(-(decay_rate * it) / MaxIt);
    
    for i = 1:GreyWolves_num
        clear rep2
        clear rep3
  
        % Choose the alpha, beta, and delta grey wolves
        Delta = SelectLeader(Archive, beta);
        Beta = SelectLeader(Archive, beta);
        Alpha = SelectLeader(Archive, beta);
        
        % If there are less than three solutions in the least crowded
        % hypercube, the second least crowded hypercube is also found
        % to choose other leaders from.
        if size(Archive, 1) > 1
            counter = 0;
            for newi = 1:size(Archive, 1)
                if sum(Delta.Position ~= Archive(newi).Position) ~= 0
                    counter = counter + 1;
                    rep2(counter, 1) = Archive(newi);
                end
            end
            Beta = SelectLeader(rep2, beta);
        end
        
        % This scenario is the same if the second least crowded hypercube
        % has one solution, so the delta leader should be chosen from the
        % third least crowded hypercube.
        if size(Archive, 1) > 2
            counter = 0;
            for newi = 1:size(rep2, 1)
                if sum(Beta.Position ~= rep2(newi).Position) ~= 0
                    counter = counter + 1;
                    rep3(counter, 1) = rep2(newi);
                end
            end
            Alpha = SelectLeader(rep3, beta);
        end
        
        % ��̬Ȩ�ؼ���
        w_alpha = 1 / (sum(Alpha.Cost) + eps);
        w_beta = 1 / (sum(Beta.Cost) + eps);
        w_delta = 1 / (sum(Delta.Cost) + eps);
        w_total = w_alpha + w_beta + w_delta;
        
        % Eq.(3.4) in the paper
        c1 = 2 .* rand(1, nVar);
        c2 = 2 .* rand(1, nVar);
        c3 = 2 .* rand(1, nVar);
        % Eq.(3.1) in the paper
        D_alpha = abs(c1 .* Delta.Position - GreyWolves(i).Position);
        D_beta = abs(c2 .* Beta.Position - GreyWolves(i).Position);
        D_delta = abs(c3 .* Alpha.Position - GreyWolves(i).Position);
        % Eq.(3.3) in the paper
        A1 = 2 .* a .* rand(1, nVar) - a;
        A2 = 2 .* a .* rand(1, nVar) - a;
        A3 = 2 .* a .* rand(1, nVar) - a;
        % Eq.(3.8) - (3.10) in the paper
        X1 = Delta.Position - A1 .* abs(D_alpha);
        X2 = Beta.Position - A2 .* abs(D_beta);
        X3 = Alpha.Position - A3 .* abs(D_delta);
        
        % ��̬��Ȩƽ��
        X_new = (w_alpha * X1 + w_beta * X2 + w_delta * X3) / w_total;
        
        % Levy ���б���
        levy_step = levy_flight(VarSize, 1.5);
        X_mutated = X_new + 0.01 * levy_step .* (ub - lb);
        
        % Boundary checking
        GreyWolves(i).Position = min(max(X_mutated, lb), ub);
        
        GreyWolves(i).Cost = fobj(GreyWolves(i).Position')';
    end
    
    GreyWolves = DetermineDomination(GreyWolves);
    non_dominated_wolves = GetNonDominatedParticles(GreyWolves);
    
    Archive = [Archive
        non_dominated_wolves];
    
    Archive = DetermineDomination(Archive);
    Archive = GetNonDominatedParticles(Archive);
    
    for i = 1:numel(Archive)
        [Archive(i).GridIndex Archive(i).GridSubIndex] = GetGridIndex(Archive(i), G);
    end
    
    if numel(Archive) > Archive_size
        EXTRA = numel(Archive) - Archive_size;
        Archive = DeleteFromRep(Archive, EXTRA, gamma);
        
        Archive_costs = GetCosts(Archive);
        G = CreateHypercubes(Archive_costs, nGrid, alpha);
    end
    
    disp(['In iteration ' num2str(it) ': Number of solutions in the archive = ' num2str(numel(Archive))]);
    save results
    
    % Results
    costs = GetCosts(GreyWolves);
    Archive_costs = GetCosts(Archive);
    
    if drawing_flag == 1
        hold off
%         scatter(costs(1,:),costs(2,:),'k.');
        hold on
%         plot(Archive_costs(1,:),Archive_costs(2,:),'LineWidth',2);
        legend('Grey wolves','Non-dominated solutions');
        drawnow
    end  
end

%% Results
for i = 1:length(Archive)
    Archive(i).Cost = Archive(i).Cost';
end
figure();
DATA = load('ZDT6.mat');% ����ZDT���Ժ�������
PF = DATA.PF;
PlotCosts(GreyWolves, Archive, PF);
pause(0.01);
a = [Archive.Cost]';
%Score = evaluation_solution(a,PF)% �����㷨����
IGD(a, PF);

% Levy �������ɺ���
function step = levy_flight(dim, beta)
    sigma = (gamma(1 + beta) * sin(pi * beta / 2) / (gamma((1 + beta) / 2) * beta * 2 ^ ((beta - 1) / 2))) ^ (1 / beta);
    u = randn(dim) * sigma;
    v = randn(dim);
    step = u ./ abs(v) .^ (1 / beta);
end