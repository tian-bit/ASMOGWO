function Plotfitness(pop,rep)
    % ��֧���
    rep_fitness=[rep.fitness];
    plot3(rep_fitness(1,:),rep_fitness(2,:),rep_fitness(3,:),'r*');
    xlabel('1^{st} Objective');
    ylabel('2^{nd} Objective');
    zlabel('3^{nd} Objective');
    grid on;
    hold off;

end

