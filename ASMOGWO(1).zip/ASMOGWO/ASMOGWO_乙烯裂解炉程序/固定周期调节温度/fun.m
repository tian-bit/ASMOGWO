function [e,f] = fun(x)
%% ����Ŀ��
x(3:end)=sort(x(3:end));
[e,f]=total_optimization(x);
%f([1 2])=-f([1 2]);
f=f';
end



