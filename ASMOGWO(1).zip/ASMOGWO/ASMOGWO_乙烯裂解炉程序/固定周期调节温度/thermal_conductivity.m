%**********************  ����ϵ������thermal_conductivity begin  ************
function   [Every_thermal_conductivity,Average_thermal_conductivity]=...
thermal_conductivity(Coil_temperature,k1,Molecular_weight,Eq_factor,...
Mol_all_everytime,Water_flow_single_mol,Every_heat_capacity,oil_viscosity_all)
T=Coil_temperature(k1-1);

% aa=[1 0.002653	6325.2	-36780	1.74e-005	7.39e-005	4.49e-005	-1.12	-20890	-2279	0.051094	9e-005	1.65e-005	2.39e-005	0.010048	1.75e-005	2.39e-005	1.65e-005	0.0021606];
% bb=[1 0.7452	0.43041	0.464	1.368	1.1689	1.2018	0.10972	0.9593	0.7656	0.45253	1.0342	1.3117	1.2694	0.4033	1.3144	1.2694	1.3117	0.76839];
% cc=[1 12	7.7e+008	-7.24e+009	439.3	500.73	421	-9834.6	-9.38e+010	-3.53e+009	5455.5	41.68	491	537	553.74	560.65	537	491	3940.5];
% dd=[1 0	-3.87e+010	0	-38700	0	0	-7.5358e+006	0	0	1.9798e+006	92938	0	0	6.8557e+005	0	0	0	-4.4534e+005];  %%19������
% Every_thermal_conductivity=aa.*T.^bb./(1+cc/T+dd/T^2);        %% w/m/K ÿ�����ʵĵ���ϵ��   lamda_i   ���㹫ʽ��Դ��

%% ����*********���á�3��169ҳ����������Ĺ�ʽ-237K���������ͬ
% water=1.75882*1e-2+5.8661*1e-5*T+1.0393*1e-7*T^2-4.507*1e-11*T^3

Molecular_weight_pluswater=[Molecular_weight,18];
Every_heat_capacity=Every_heat_capacity*4.184;     %% ��λ J/mol.k
Every_thermal_conductivity=4.184*oil_viscosity_all.*(0.239*Every_heat_capacity+2.48)./Molecular_weight_pluswater;
water=1.75882*1e-2+5.8661*1e-5*T+1.0393*1e-7*T^2-4.507*1e-11*T^3;
Every_thermal_conductivity(19)=water;

Oil_thermal_conductivity_factor=[Every_thermal_conductivity(2:3),Every_thermal_conductivity(5:12)];
Molecular_weight_single=[Molecular_weight(2:3),Molecular_weight(5:12)];

tt=Eq_factor(7);
Eq_factor(7)=Eq_factor(9);
Eq_factor(9)=tt;

s1=sum(Molecular_weight_single.^(1/3).*Oil_thermal_conductivity_factor.*Eq_factor);      %w/m/K  ��3��169ҳ
s2=sum(Molecular_weight_single.^(1/3).*Eq_factor);
Oil_thermal_conductivity=s1/s2;                     %ʯ���͵ĵ���ϵ��  lamda_o
Every_thermal_conductivity(1)=Oil_thermal_conductivity;

Molecular_weight_pluswater=[Molecular_weight,18];
Mol_all_everytime_pluswater=[Mol_all_everytime,Water_flow_single_mol];

Average_thermal_conductivity=sum(Molecular_weight_pluswater.^(1/3).*...
Every_thermal_conductivity.*Mol_all_everytime_pluswater)./sum(Molecular_weight_pluswater.^(1/3).*...
Mol_all_everytime_pluswater);    %%%% J/s/m/K    %�������ĵ���ϵ��  lamda_m

%**********************  ����ϵ������thermal_conductivity end   ************
end