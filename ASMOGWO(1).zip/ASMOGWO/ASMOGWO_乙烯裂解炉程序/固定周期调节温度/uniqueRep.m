function rep = uniqueRep(rep)
% global nVar sizepop nObj
fitnessFA = [];
fitnessFA = [rep.fitness];  % ��Ӧ��ֵ
% fitnessFA = [reshape( fitnessFA, [nObj, sizepop] )]';  % ��Ӧ��ֵ
flag = [];
for i=1:size(fitnessFA,2)-1
    for j=i+1:size(fitnessFA,2)
        if fitnessFA(1,j)==fitnessFA(1,i) && fitnessFA(2,i)==fitnessFA(2,j)
            flag = [flag,j];
        end
    end
end
flag = unique(flag);
rep(flag) = [];





