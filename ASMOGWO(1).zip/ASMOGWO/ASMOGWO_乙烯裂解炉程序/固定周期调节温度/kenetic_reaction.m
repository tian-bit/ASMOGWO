%%���¹�ʽ�������ס�3��36-40ҳ
%**********************%%reaction equations set***************************
% % Rv1=Kv(1)*Nn(1)
% % Rv2=Kv(2)*Nn(6)
% % Rv3=Kv(3)*Nn(7)
% % Rv4=Kv(4)*Nn(4)*Nn(5)/Vf
% % Rv5=Kv(5)*Nn(6)
% % Rv6=Kv(6)*Nn(5)*Nn(6)/Vf
% % Rv7=Kv(7)*Nn(8)
% % Rv8=Kv(8)*Nn(8)
% % Rv9=Kv(9)*Nn(5)*Nn(8)/Vf
% % Rv10=Kv(10)*Nn(7)
% % Rv11=Kv(11)*Nn(7)
% % Rv12=Kv(12)*Nn(6)*Nn(7)/Vf
% % Rv13=Kv(13)*Nn(11)
% % Rv14=Kv(14)*Nn(11)
% % Rv15=Kv(15)*Nn(11)
% % Rv16=Kv(16)*Nn(11)
% % Rv17=Kv(17)*Nn(10)
% % Rv18=Kv(18)*Nn(10)
% % Rv19=Kv(19)*Nn(5)*Nn(9)/Vf
% % Rv20=Kv(20)*Nn(7)*Nn(9)/Vf
% % Rv21=Kv(21)*Nn(9)*Nn(10)/Vf
% % Rv22=Kv(22)*Nn(9)*Nn(9)/Vf
%************************************************************************
% % % 1    Naphtha      9   C4H6          17  C6+
% % % 2    H2           10  1-C4H8        18  CnH2n-6
% % % 3    CH4          11  n-C4H10
% % % 4    C2H2         12  C4S
% % % 5    C2H4         13  C6H6
% % % 6    C2H6         14  C7H8
% % % 7    C3H6         15  C8H8
% % % 8    C3H8         16  C8H10
%%dN=-Rv*F
function     [ u, dMol_all, Fc]=kenetic_reaction(Mol_plus_all,Mol_all,...
          Coil_area_in,k1,k2,Coil_pressure,Coil_temperature,Eq_factor,Coil_number) 
R_Kv=8.3145;     %% J/(mol.K) ��������ϵ��     1J=1Pa*m3
Mol_plus_all=Mol_plus_all/Coil_number;
Mol_all=Mol_all/Coil_number;
P = Coil_pressure(k1-1);                                                          %%input pressure of every iteration       :Kpa                         
T = Coil_temperature(k1-1);                                                       %%input temperature of every iteration    :K
S = Coil_area_in(k2);                                                              %%cross-sectional area of section        :cm2
j=k1;
%*************************************************************************
% activation energy, kcal/mol
E = [52.58 65.21 65.33 41.26 65.25 60.43 51.29 50.6 59.06 64.17 56.9 60.01 59.64 70.68 61.31 62.36 50.73 50.00 34.36 35.64 57.97 29.76];   %���ס�2�� 35ҳ
E = E*4.1845;         %MJ/Kmol,1cal=4.1845J
%% frequency factors
A = [6.565e11 4.652e13 7.284e12 1.026e15 3.750e12 7.083e16 5.888e10 4.692e10 2.536e16 7.386e12 2.424e11 1.000e17 7.000e12 7.000e14 4.099e12 1.637e12 2.075e11 1.000e10 8.385e12 9.740e11 6.400e17 1.510e12];                                                       %%univeral gass constant                   :J/(mol.K)
RT = 1./(T*R_Kv*1.e-3);                                              %%intermediate variable
Kv = A .* exp(-E * RT);                                              %for the first order and second order reaction  :1/s ,cm3/(mol.s) respectively, reaction velosity
%*************************************************************************

%*************************************************************************
Vf = 1e3*R_Kv*Mol_plus_all*T/P;                                      %cm3/s  �������
Fc=S/Vf;                                                                   %%intermediate variable   :s/cm
u=1/Fc*1e-2;                 %m/s

%*************************************************************************
Nn = Mol_all(j-1,:);
dMol_all=[      -Kv(1)*Nn(1)*Fc;...
          (Eq_factor(1)*Kv(1)*Nn(1)+Kv(2)*Nn(6)+Kv(7)*Nn(8)+Kv(14)*Nn(11)+Kv(16)*Nn(11)+Kv(18)*Nn(10)+2*Kv(19)*Nn(5)*Nn(9)/Vf+2*Kv(20)*Nn(7)*Nn(9)/Vf+2*Kv(21)*Nn(9)*Nn(10)/Vf+2*Kv(22)*Nn(9)*Nn(9)/Vf)*Fc;...
          (Eq_factor(2)*Kv(1)*Nn(1)+Kv(3)*Nn(7)+Kv(5)*Nn(6)+Kv(6)*Nn(5)*Nn(6)/Vf+Kv(8)*Nn(8)+3*Kv(11)*Nn(7)+Kv(12)*Nn(6)*Nn(7)/Vf+Kv(13)*Nn(11))*Fc;...
          (Kv(3)*Nn(7)-Kv(4)*Nn(4)*Nn(5)/Vf)*Fc;...
          (Eq_factor(3)*Kv(1)*Nn(1)+Kv(2)*Nn(6)-Kv(4)*Nn(4)*Nn(5)/Vf-Kv(6)*Nn(5)*Nn(6)/Vf+Kv(8)*Nn(8)-Kv(9)*Nn(5)*Nn(8)/Vf+3*Kv(10)*Nn(7)+2*Kv(14)*Nn(11)+Kv(15)*Nn(11)-Kv(19)*Nn(5)*Nn(9)/Vf)*Fc;...
          (Eq_factor(4)*Kv(1)*Nn(1)-Kv(2)*Nn(6)-2*Kv(5)*Nn(6)-Kv(6)*Nn(5)*Nn(6)/Vf+Kv(9)*Nn(5)*Nn(8)/Vf-Kv(12)*Nn(6)*Nn(7)/Vf+Kv(15)*Nn(11))*Fc;...
          (Eq_factor(5)*Kv(1)*Nn(1)-Kv(3)*Nn(7)+Kv(6)*Nn(5)*Nn(6)/Vf+Kv(7)*Nn(8)+Kv(9)*Nn(5)*Nn(8)/Vf-2*Kv(10)*Nn(7)-2*Kv(11)*Nn(7)-Kv(12)*Nn(6)*Nn(7)/Vf+Kv(13)*Nn(11)-Kv(20)*Nn(7)*Nn(9)/Vf)*Fc;...
          (Eq_factor(6)*Kv(1)*Nn(1)+Kv(5)*Nn(6)-Kv(7)*Nn(8)-Kv(8)*Nn(8)-Kv(9)*Nn(5)*Nn(8)/Vf)*Fc;...
          (Eq_factor(9)*Kv(1)*Nn(1)+Kv(4)*Nn(4)*Nn(5)/Vf+Kv(18)*Nn(10)-Kv(19)*Nn(5)*Nn(9)/Vf-Kv(20)*Nn(7)*Nn(9)/Vf-Kv(21)*Nn(9)*Nn(10)/Vf-2*Kv(22)*Nn(9)*Nn(9)/Vf)*Fc;...
          (Eq_factor(8)*Kv(1)*Nn(1)+Kv(12)*Nn(6)*Nn(7)/Vf+Kv(16)*Nn(11)-Kv(17)*Nn(10)-Kv(18)*Nn(10)-Kv(21)*Nn(9)*Nn(10)/Vf)*Fc;...
          (Eq_factor(7)*Kv(1)*Nn(1)-Kv(13)*Nn(11)-Kv(14)*Nn(11)-Kv(15)*Nn(11)-Kv(16)*Nn(11))*Fc;...
          (Eq_factor(10)*Kv(1)*Nn(1))*Fc;...
          (Kv(19)*Nn(5)*Nn(9)/Vf)*Fc;...
          (Kv(20)*Nn(7)*Nn(9)/Vf)*Fc;...
          (Kv(22)*Nn(9)*Nn(9)/Vf)*Fc;...
          (Kv(21)*Nn(9)*Nn(10)/Vf)*Fc;...
          (0.14*Kv(11)*Nn(7)+0.19*Kv(17)*Nn(10))*Fc;...
          (0.3*Kv(11)*Nn(7)+0.41*Kv(17)*Nn(10))*Fc;...
      ];
   dMol_all=dMol_all';                %mol/s/cm
   dMol_all=Coil_number*dMol_all;    
end
%*************************************************************************
    