function [ep,fv]=total_optimization(x)

N_run=101;  
% Oil_flow=x(1);
% Dilution_steam_ratio=x(2);
% Oil_flow_opt=x(1);
% Dilution_steam_ratio_opt=x(2);
%  Outlet_temperature=x(3:72); 
% Oil_flow_opt=890.625;
% Dilution_steam_ratio_opt=0.6;
%  Outlet_temperature=x(1:70); 
Oil_flow_opt=x(2); %ʯ��������
Dilution_steam_ratio_opt=x(1); %��������
% Outlet_temperature=x(3:103);
crack_day_least=40;
Outlet_temperature(1:7)=x(3); 
Outlet_temperature(8:14)=x(4); 
Outlet_temperature(15:21)=x(5); 
Outlet_temperature(22:28)=x(6);   
Outlet_temperature(29:35)=x(7);  
Outlet_temperature(36:42)=x(8); 
Outlet_temperature(43:49)=x(9);
Outlet_temperature(50:56)=x(10);
Outlet_temperature(57:63)=x(11);
% Outlet_temperature(65:71)=x(12);
Mol_all_eth_least=20.1134;
Mol_all_prop_least=10.483;
temperature_limit=1388;
%%%%%%%%%%%%%%%%%%%
 Inlet_temperature=875;    %����¶�        
% Outlet_temperature=849+273;       %�����¶�-OV      
Inlet_temperature_out=1100;   %�ܱ��¶�          
 Outlet_pressure=178;        %����ѹ��          
% Dilution_steam_ratio=0.6;           %�����ȣ�ˮ�ͱȣ�-OV  
% Oil_flow=890.625;   %������-OV
Inlet_pressure=254.7;   %���ѹ��--�����ܳ����У�һ��ϵ����ȡ���򣩸���T��COP����ȡ 
%************oil charateristics***********       
Oil_P=0.6561;                              %%��Ʒ����������
Oil_N=0.2639;                              %%��Ʒ��˫������������
Oil_A=0.08;                               %%��Ʒ�з��������� 
d_water=0.7021;   
mbp=363.148;
Special_factor=1.216*mbp^(1/3)/d_water;
Oil_molecular_weight=52.63-0.246*mbp+0.001*mbp^2;  
% Special_factor=12.3562;                       %�������������Ѿ������ 
% Oil_molecular_weight=95.1722;

Eq_factor=[0.454510699	0.987954874	0.976098773	0.145988137	0.459590386	0.008168442	0.014864899	0.201125855	0.111251206	0.186731745];   %�����ܳ����У�һ��ϵ����ȡ�����Ż��õ�
gx_1=0;
gx_2=0;
gx_3=0;
gx_4=0;
% i_Day=50*24;        %cracking period
% i_Day=i_Day+1;
% Outlet_temperature=(849+273)*ones(1,i_Day);       %�����¶�-OV 
i_day=size(Outlet_temperature,2); 
Mol_all_eth=zeros(i_day,N_run);
Mol_all_prop=zeros(i_day,N_run);
Mol_all_buta=zeros(i_day,N_run);
Mol_all_but=zeros(i_day,N_run);
Mol_all_hyd=zeros(i_day,N_run);
Mol_all_meth=zeros(i_day,N_run);

Day=zeros(i_day,1);
Tube=zeros(N_run,1);

for i=0:(i_day-1)
    Day(i+1)=i;
end
for j=0:(N_run-1);
    Tube(j+1)=j;
end

rcc=zeros(i_day,N_run);   %�ό����
dCoil_diameter=zeros(i_day,N_run);    %������
Coil_temperature_out_pic=zeros(i_day,N_run);   %�ܱ��¶�
Coil_temperature_pic=zeros(i_day,N_run);       %�ѽ����¶�
Coil_retongliang=zeros(i_day,N_run);           %¯������ͨ��
Coil_pressure_pic=zeros(i_day,N_run);          %�ѽ���ѹ��
Tggg_pic=zeros(i_day,N_run);                   %�����¶�
dtao=zeros(i_day-1,1);                         %ͣ��ʱ��

%**************************furnace structure**********************
Coil_length_all=28.602*1e2;             %%cm   ���ӵ��ܳ���
Coil_length_first=13.681*1.e2;          %%cm   ��һ�ι��ӵĳ���    
Coil_length_second=14.921*1.e2;         %%cm   �ڶ��ι��ӵĳ���    
Coil_diameter_in =[5.1;7.3];            %%cm   �˹��Ǳ侶�ܣ�ǰ��Ĺ��ھ���ͬ    
Coil_diameter_out=[6.3;8.6];            %%cm   ���⾶                                                                                      
Coil_pitch=[11.2;15.4];                 %%cm   �ܼ��
Coil_thickness=[0.60;0.65];             %%cm   �ܱڵĺ��

dCoil_length=Coil_length_all/100;       %cm  �ֶη�

Molecular_weight=[0,2,16,26,28,30,42,44,54,56,58,48, 78, 92,104,106,72,106];          %%g/mol    �������ʵķ�����   
Molecular_weight(1)=Oil_molecular_weight;       %%g/mol   ����һ�����ʴ��� 

for i_coking=2:(i_day)  
    Oil_flow=Oil_flow_opt;  
    Dilution_steam_ratio=Dilution_steam_ratio_opt;
Tg_modi_factor=0;   %�����¶ȵ������ӣ����������¶�

     for l=1:3           %adjusting COT automatically instead of manually

Oil_flow_single=Oil_flow;    %%kg/h   ÿ�����ӵ����������
Water_flow_single=Dilution_steam_ratio*Oil_flow_single; %%kg/h ÿ�����ӵ�ˮ�������
flow_all=Oil_flow_single+Water_flow_single;       %%kg/h  ���ܵ�������                                
Water_flow_single_mol=Water_flow_single*1.e3/18/3600;   %%mol/s 
Oil_flow_single_mol=Oil_flow_single*1.e3/Oil_molecular_weight/3600;   %%mol/s   ����Ħ������
flow_all_mol=Water_flow_single_mol+Oil_flow_single_mol;  %% mol/s     

%**************************************************************************
Coil_pressure=zeros(N_run,1);                %%Kpa    ���ڸ����ѹ��                                                    
Coil_pressure(1)=Inlet_pressure;             %%Kpa ���ٶ������ѹ������      
Coil_pressure_pic(i_coking,1)=Inlet_pressure;       

Coil_temperature=zeros(N_run,1);             %% K     ���ڸ�����¶�                                               
Coil_temperature(1)=Inlet_temperature;       %% K     ����ʼ���¶ȴ���
Coil_temperature_pic(i_coking,1)=Inlet_temperature;       %% K     ����ʼ���¶ȴ���

Coil_temperature_out=zeros(N_run,1);            %% K     �ܱڸ�����¶�                                                
Coil_temperature_out(1)=Inlet_temperature_out; 

Molecular_weight_average=zeros(N_run,1);     %% g/mol  ƽ��������
Molecular_weight_average(1)=flow_all/flow_all_mol*1.e3/3600;        %% g/mo/��һ�ε�ƽ�������� 
Mol_all = zeros(N_run,18);              %%����������ÿһ�����Ħ����        mol/s                                           
Mol_all(1,:) = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];  %% ��һ�θ����Ħ����                      
Mol_all(1)=Oil_flow_single_mol;  
  
Test1=zeros(N_run,1);                            %%�������ݳ�ʼ��
Test1(1)=Oil_flow_single_mol;                    %������Ħ������

Tggg=zeros(N_run,1);
Tggg(1)=1400-Tg_modi_factor; 
Length=zeros(N_run,1);
Length(2)=dCoil_length/100;      %m
tao=0;      %ÿ��ͣ��ʱ��

%**********************cracking process*******************************************
for k1=2:N_run
           if  (k1-1)*dCoil_length < Coil_length_first     %�ж��ǵ�һ�̻��ǵڶ���
                k2=1;Coil_number=2;       
           else
               k2=2;Coil_number=1;
           end
           
Mol_all_everytime=Mol_all(k1-1,:);
Length(k1)=Length(k1-1)+dCoil_length/100;  %m
 %*************************************************************************
 %                         �ό        
 %************************************************************************
           
[rc,dCoking]=coking(Coil_temperature,k1,Mol_all_everytime,Coil_pressure);
rcc(i_coking,k1)=rc*1e3;     %g.coke/m2.hr
dCoil_diameter_this=dCoil_diameter(i_coking,:);
dCoil_diameter_last=dCoil_diameter((i_coking-1),:);
dCoil_diameter_this(k1)=dCoil_diameter_last(k1)+dCoking/10;   %%cm
dCoil_diameter(i_coking,:)=dCoil_diameter_this;
Coil_diameter_in =[5.1;7.3];
Coil_diameter_in=Coil_diameter_in-2*dCoil_diameter_this(k1);
Coke_thickness=dCoil_diameter_this(k1);     %%cm  ������
Coil_area_in = pi/4*Coil_diameter_in.^2;   %%cm2  ���ھ��ĺ����� 

%**************************************************************************
       Mol_plus_all=sum(Mol_all(k1-1,:))+Water_flow_single_mol;   %% mol/s ����ĳ���ܵ�mol����
       Molecular_weight_average(k1)=flow_all*1.e3/3600/(Mol_plus_all);   %%g/mol                
       
%mass balance equation
[u,dMol_all,Fc]=kenetic_reaction(Mol_plus_all,Mol_all,Coil_area_in,k1,k2,Coil_pressure,Coil_temperature,Eq_factor,Coil_number);       %�����Ħ�����ʱ仯
tao=tao+Fc*dCoil_length;    %΢Ԫ��ͣ��ʱ��  s
  for k3 = 1:18     %����
          Mol_all(k1,k3) = Mol_all(k1-1,k3) + dMol_all(k3)*dCoil_length;    %mol/s
          if Mol_all(k1,k3) < 0
             Mol_all(k1,k3) = 0;
          end
  end
Test1(k1)=sum( Mol_all(k1,:)); 
  
[oil_viscosity_average,oil_viscosity_all]=oil_viscosity(Mol_all_everytime,Eq_factor,...
    k1,Coil_temperature, Molecular_weight,Water_flow_single_mol);

[Every_heat_capacity,Every_heat_of_reaction,Average_heat_capacity]=...
    temperature_exchange_factor(Oil_P,Oil_N,Oil_A,Oil_molecular_weight,...
    Coil_temperature,k1,Mol_all_everytime,Molecular_weight,...
    Water_flow_single_mol,Special_factor,d_water);      

[Every_thermal_conductivity,Average_thermal_conductivity]=...
thermal_conductivity(Coil_temperature,k1,Molecular_weight,Eq_factor,...
Mol_all_everytime,Water_flow_single_mol,Every_heat_capacity,oil_viscosity_all);

 [Coil_heat_transfer_coefficient_in,Coil_heat_transfer_coefficient]=...%�ڱڴ���ϵ��
     Heat_transfer_coefficient_caculate...
    (Coil_thickness,Coil_diameter_out,k2,k1,Coil_number,Coil_temperature_out,...
   Mol_all_everytime,Average_thermal_conductivity,Average_heat_capacity,flow_all,...
   oil_viscosity_average,Molecular_weight_average,Coke_thickness);                      

[Q33,Q22,Q11,Coil_temperature_this,Coil_temperature_out_this,Tg]=temperature_exchange...
    (Every_heat_capacity,...
    Every_heat_of_reaction,Coil_temperature,k1,k2,Mol_all,...
    Water_flow_single_mol,dCoil_length,Coil_diameter_in,Coil_number,...
    Coil_temperature_out,Coil_diameter_out,Coil_heat_transfer_coefficient,...
    Coil_length_first,Coil_length_second,i_coking,Coil_pitch,Tg_modi_factor);
Tggg(k1)=Tg;                                                      %��ͨ�� �����¶� �ܱ��¶� �ѽ����¶�
Tggg_pic(i_coking,k1)=Tg;
Coil_temperature(k1)=Coil_temperature_this;
Coil_temperature_pic(i_coking,k1)=Coil_temperature_this;
Coil_temperature_out(k1)=Coil_temperature_out_this;
Coil_temperature_out_pic(i_coking,k1)=Coil_temperature_out_this;
Coil_retongliang(i_coking,k1)=Q22*10/36;     %J/s/m2

%%***********************************************************************ѹ����
[dCoil_pressure,Re,f]=pressure_down(Coil_diameter_in,Coil_diameter_out,Coil_pressure,Coil_temperature,k1,k2,flow_all,Molecular_weight_average,Coil_pitch,oil_viscosity_average,Coil_number,Coil_length_all,dCoil_length,Coil_length_first,Coil_thickness);
     dCoil_pressure=dCoil_pressure*dCoil_length;   %KPa
     Coil_pressure(k1)=Coil_pressure(k1-1)+dCoil_pressure;
     Coil_pressure_pic(i_coking,k1)= Coil_pressure(k1);
     
Mol_all_eth(i_coking,k1)=Mol_all(k1,5)*28/(Oil_flow_single_mol)/Oil_molecular_weight*100;
Mol_all_prop(i_coking,k1)=Mol_all(k1,7)*42/(Oil_flow_single_mol)/Oil_molecular_weight*100;
Mol_all_buta(i_coking,k1)=Mol_all(k1,9)*54/(Oil_flow_single_mol)/Oil_molecular_weight*100;
Mol_all_but(i_coking,k1)=Mol_all(k1,10)*56/(Oil_flow_single_mol)/Oil_molecular_weight*100;
Mol_all_hyd(i_coking,k1)=Mol_all(k1,2)*2/(Oil_flow_single_mol)/Oil_molecular_weight*100;
Mol_all_meth(i_coking,k1)=Mol_all(k1,3)*16/(Oil_flow_single_mol)/Oil_molecular_weight*100;
     
%**************************************************************************

%**********************   ����ƽ��  ****************************************
%**********************   END  ******************************************

%**************************************************************************
%*******************      ��ѭ��   ****************************************
%*******************       END      ***************************************
end

      if (Coil_temperature_this==Outlet_temperature(1,i_coking-1))
            break;
       else 
          Tg_modi_factor=Tg_modi_factor+Coil_temperature_this-Outlet_temperature(1,i_coking-1);
       end
end
    try 
dtao(i_coking-1)=tao;
Coil_diameter_in_ub=[6.3 8.6 8.6 8.6 8.6 8.6 8.6 8.6 8.6];
Coil_diameter_in_ub=Coil_diameter_in_ub.*0.5.*0.25;
dCoil_diameter_x=i_coking;
dCoil_diameter_o=cat(2,dCoil_diameter(dCoil_diameter_x,48),dCoil_diameter(dCoil_diameter_x,94:101));
gx_1=sum(max(dCoil_diameter_o-Coil_diameter_in_ub,repmat(0,1,9)));%%%%%�ܾ�Լ��
gx_2=gx_2+min(0,(Mol_all_eth(i_coking,N_run)-Mol_all_eth_least));%%%����Լ��
gx_3=gx_3+min(0,(Mol_all_prop(i_coking,N_run)-Mol_all_prop_least));
gx_4=gx_4+min(0,(temperature_limit-max(Coil_temperature_out)));%%%�¶�Լ��
if(gx_1>0||gx_2<0||gx_3<0||gx_4<0)
         fv(1)=1e6;
         fv(2)=1e6;
%         fv(3)=1e6;
%         fv(4)=1e6;
end
% if(gx_1>0)
%     crack_day=i_coking-1;
%   gx_5=sum(max((Outlet_temperature(1:(crack_day-1))-Outlet_temperature(2:crack_day)),zeros(1,crack_day-1)));
%      gx_6=min(0,(crack_day-crack_day_least));
%     fv(1)=(-sum(Mol_all_eth(:,N_run)))/crack_day+1e6*(abs(gx_2)+abs(gx_3)+abs(gx_4)+abs(gx_5)+abs(gx_6));
%     fv(2)=(-sum(Mol_all_prop(:,N_run)))/crack_day+1e6*(abs(gx_2)+abs(gx_3)+abs(gx_4)+abs(gx_5)+abs(gx_6));
%     fv(3)=Oil_flow_opt+1e6*(abs(gx_2)+abs(gx_3)+abs(gx_4)+abs(gx_5)+abs(gx_6));
%     fv(4)=Water_flow_single+1e6*(abs(gx_2)+abs(gx_3)+abs(gx_4)+abs(gx_5)+abs(gx_6));
%     fv(5)=(sum(Coil_retongliang(:,N_run)))/crack_day+1e6*(abs(gx_2)+abs(gx_3)+abs(gx_4)+abs(gx_5)+abs(gx_6));
% %     fv(6)=-crack_day+1e6*(abs(gx_2)+abs(gx_3)+abs(gx_4)+abs(gx_5)+abs(gx_6));
% %     fv(7)=var(Mol_all_eth(:,N_run))+1e6*(abs(gx_2)+abs(gx_3)+abs(gx_4)+abs(gx_5)+abs(gx_6));
% %     fv(8)=var(Mol_all_prop(:,N_run))+1e6*(abs(gx_2)+abs(gx_3)+abs(gx_4)+abs(gx_5)+abs(gx_6));
%     
%     if (~isreal(fv))
%         fv(1)=1e6;
%         fv(2)=1e6;
%         fv(3)=1e6;
%         fv(4)=1e6;
%         fv(5)=1e6;
%         fv(6)=1e6;
%         fv(7)=1e6;
%         fv(8)=1e6;
%     end
%     return;
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    catch
        fv(1)=1e6;
        fv(2)=1e6;
%        fv(3)=1e6;
%        fv(4)=1e6;
%         fv(5)=1e6;
%         fv(6)=1e6;
%         fv(7)=1e6;
%         fv(8)=1e6;
        return;
    end
%%*******************   �ό  *********************************************
%%*******************   end   *********************************************
end
    try
     crack_day=63;
%     T_work=340-3*floor(340/crack_day);
%     T_span=floor(T_work/crack_day);
%     T_leave=mod(T_work,crack_day);
%     coef_leave=1;
%     if (T_leave==0)
%         T_leave=1;
%         coef_leave=0;
%     end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�����Լ����Ϊ�ѽ���ѽ��������%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % % % % % % % % % % % % % % % gx_5=sum(max((Outlet_temperature(1:(crack_day-1))-Outlet_temperature(2:crack_day)),zeros(1,crack_day-1)));
% % % % % % % % % % % % % % % %       fv(1)=(-sum(Mol_all_eth(:,N_run)))/crack_day+1e6*(abs(gx_5)+abs(gx_6));
% % % % % % % % % % % % % % % %     fv(2)=(-sum(Mol_all_prop(:,N_run)))/crack_day+1e6*(abs(gx_5)+abs(gx_6));
% % % % % % % % % % % % % % % %     fv(3)=-crack_day;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%����Ŀ����Ϊ�ѽ�ܽ�������%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    gx_5=sum(max((Outlet_temperature(1:(crack_day-1))-Outlet_temperature(2:crack_day)),zeros(1,crack_day-1)));
    gx_6=min(0,(crack_day-crack_day_least));
    fv(1)=(-sum(Mol_all_eth(:,N_run)))/crack_day+1e6*(abs(gx_2)+abs(gx_3)+abs(gx_4)+abs(gx_5)+abs(gx_6));
    fv(2)=(-sum(Mol_all_prop(:,N_run)))/crack_day+1e6*(abs(gx_2)+abs(gx_3)+abs(gx_4)+abs(gx_5)+abs(gx_6));
     ep(:,1)=Outlet_temperature; %63���¶ȴ���ep��
     ep(:,2) = Mol_all_eth(:,N_run); %63����ϩ����
     ep(:,3)= Mol_all_prop(:,N_run);
%    fv(3)=Oil_flow_opt+1e6*(abs(gx_2)+abs(gx_3)+abs(gx_4)+abs(gx_5)+abs(gx_6));
%    fv(4)=Water_flow_single+1e6*(abs(gx_2)+abs(gx_3)+abs(gx_4)+abs(gx_5)+abs(gx_6));
%     fv(6)=-crack_day+1e6*(abs(gx_2)+abs(gx_3)+abs(gx_4)+abs(gx_5)+abs(gx_6));
%     fv(7)=var(Mol_all_eth(:,N_run))+1e6*(abs(gx_2)+abs(gx_3)+abs(gx_4)+abs(gx_5)+abs(gx_6));
%     fv(8)=var(Mol_all_prop(:,N_run))+1e6*(abs(gx_2)+abs(gx_3)+abs(gx_4)+abs(gx_5)+abs(gx_6));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
%     fv(1)=(-sum(Mol_all_eth(:,N_run)))/crack_day+1e6*(abs(gx_2)+abs(gx_3)+abs(gx_4)+abs(gx_5));
%     fv(2)=(-sum(Mol_all_prop(:,N_run)))/crack_day+1e6*(abs(gx_2)+abs(gx_3)+abs(gx_4)+abs(gx_5));    
    if (~isreal(fv))
         fv(1)=1e6;
         fv(2)=1e6;
 %        fv(3)=1e6;
 %        fv(4)=1e6;
%          fv(5)=1e6;
%          fv(6)=1e6;
%          fv(7)=1e6;
%          fv(8)=1e6;
    end
    catch
        fv(1)=1e6;
        fv(2)=1e6;
 %       fv(3)=1e6;
 %       fv(4)=1e6;
%         fv(5)=1e6;
%         fv(6)=1e6;
%         fv(7)=1e6;
%         fv(8)=1e6;
    end 
end



