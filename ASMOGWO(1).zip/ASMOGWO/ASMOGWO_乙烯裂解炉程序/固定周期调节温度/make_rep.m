function rep=make_rep(rep,pop,sizepop,kec)
%���¾�Ӣ�⼯
N1=length(rep);N2=length(pop);
for i=1:N1
pop(N2+i)=rep(i);
end

pop=JudgePopDomination(pop,kec);
% ��ʼ����Ӣ�⼯
rep=pop(~[pop.IsDominated]);
for i=1:length(rep)
rep(i).ufit=my_constraint(rep(i).Pos);
end


end