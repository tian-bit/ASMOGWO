% ����������ǰ��
function paretoFront = CalculateParetoFront(BestCosts)
    paretoFront = zeros(size(BestCosts));
    paretoFront(1, :) = BestCosts(1, :);
    nPareto = 1;
    
    for i = 2:size(BestCosts, 1)
        dominated = false;
        for j = 1:nPareto
            if all(BestCosts(i, :) >= paretoFront(j, :))
                dominated = true;
                break;
            end
        end
        
        if ~dominated
            nPareto = nPareto + 1;
            paretoFront(nPareto, :) = BestCosts(i, :);
        end
    end
    
    paretoFront = paretoFront(1:nPareto, :);
end