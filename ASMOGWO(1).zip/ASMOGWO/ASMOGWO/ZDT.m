%% ZDT1���Ժ�����������壬���Ŀ�꺯��[f1;f2];
             function z=ZDT(x)
                 n=numel(x);
                 f1=x(1);    
                 g=1+9/(n-1)*sum(x(2:end));    
                 h=1-sqrt(f1/g);    
                 f2=g*h;   
                 z=[f1
                    f2];
             end
% ZDT2
%         function z=ZDT(x)
%              n=numel(x);
%              f1=x(1);    
%              g=1+9/(n-1)*sum(x(2:end));    
%              h=1-(f1/g)^2;    
%              f2=g*h;   
%              z=[f1
%                 f2];
%          end
%ZDT3
%         function z=ZDT(x)
%                   n=numel(x);       
%                   f1=x(1);          
%                   g=1+9/(n-1)*sum(x(2:end));           
%                  h=(1-sqrt(f1/g)-f1/g*sin(10*pi*x(1)));          
%                   f2=g*h;           
%                  z=[f1
%                      f2];
%               
%               end
%ZDT4
%         function z=ZDT(x)
%               n=numel(x);
%               f1=x(1);    
%               g=1+10*(n-1)+sum(x(2:end).*x(2:end) - 10*cos(4*pi*x(2:end)));    
%               h=1-sqrt(f1/g);    
%               f2=g*h;   
%               z=[f1
%                  f2];
%           end
% % % ZDT6 
%      function z=ZDT(x)
%                   numVar = length(x);
%                    g = 1 + 9 * (sum(x(2:numVar))/(numVar-1))^0.25;
%                   f1 = 1 - exp(-4*x(1)) * sin(6*pi*x(1))^6;
%                    f2 = g * (1 - (f1/g)^2);
%                    z = [f1
%                          f2];
%               end
%        
